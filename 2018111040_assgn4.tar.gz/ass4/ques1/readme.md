The problem statement is as given in the pdf.

In the code given, ( It is being modelled along the lines of the code given in the pdf )


Implement The Quicksort the normal way

Implement The Quicksort the Processes way

Implement The Quicksort the Threads way


Result : For smaller values, Threads are the slowest and the normal Quicksort is the fastest

Expected impact dosen't come because the OS in an attempt to optimise the time (it dosen't want a single thread to use all the resources) forces the threads to wait. Hence it takes a long time even to get basic work done.

