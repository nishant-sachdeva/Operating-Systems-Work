this doc will trace how I am going about the assigment


6th november, 2019

7'09 am : I have started  work. opened all tabs. I am leaving to freshen up. all changes added

7'44 am : Back from the freshen up thing. Pomodoro starts : Ratio : 25 - 5 

8'10 am : First pomodoro ends: work is underway to understand how to change the proc structure sagely

6'32 pm : I have been away the entire day but atm i am looking to make the getpinfo syscall work and hopefully by before dinner, I will have the whole task 1 functioning.I am not gonna sit down to work right now as I have some esw matter to attend but I will settle down at the earliest and should I not have dinner company, I will mostly look to skip that in  order that I get a decent shot at working through the other tasks today. Under no condition am I to relent until my sys calls for task1  are functioning

7'05 pm : And so it starts, the journey to the finish for the waitx sys call and the getpinfo sys call - I'll keep coming back and checking up on you ! (valar morghulis)

Pomodoro starts : May the best guy win

9'35 pm : We start work rn. we will look to end only as and when we finish TASK 1

11'20 pm : I have been at yashas's room . It seems I will be able to finish up the normal sys calls stuff

Things seem to be looking up

END OF DAY

8'45 am : sys calls yet to be finished. I am pretty confused about the nature and requirement of these sys calls. I don't quite know how to go about things presently. But I cling to the hope that as the day progresses, I will benefit from further better insights

11:26 am : I have a lot of questions about these calls. something happens and then a lot of things don't happen. Anyway, her we are, algo class presents another opportunity to try this thing. So, here we go, hope this session goes better than it's ancestors.

2'22 pm: well well well, here we are. nothing much has happenned since forever now. But i am not giving up just yet , I know there is still hope of finishing at least this  task 1. And so I will keep working on it. And hopefully with help from my friends and god, be able to come out of this with some dignity. Pomodoro starts :  first round : meditation

3'57 pm : waitx compiled. I assume that it's working the way it is suppossed to be working!! Yipee, finally some light at the end of the tunnel

okay, bournvita break before I go over to the other one that has yet evaded me, the getpinfo thing. I supposse that will be nice to me as well. Let's see then. Bye for now

5'43 pm : ahaan , it does appear so that I take irrationally long breaks. I mean no wonder, it's been approx 2 hrs since I left work for a "short" break. anyway , here I am , and now we will try and get getpinfo right. let
s see how it goes. Work starts . Mostly a fight to the finish except the possibility of ending up around dinner time. and this dinner time I intend to postpone as much as possible. let's see how this session goes

9'33 pm : Getpinfo seems to be working fine atm , so here's what we will look to do , spend 10 mins and try to fix the part where the run time seems to be going all wron

9'33 pm : Getpinfo seems to be working fine atm , so here's what we will look to do , spend 10 mins and try to fix the part where the run time seems to be going all wrong. So , over and back it is, so let's see what happens

10'53 pm : the first task is done. so some relief is there. now , i will get to work with the remaining tasks
